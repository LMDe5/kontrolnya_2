﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Trap : GameObject, IInteractable, IDamageable
    {
        private static int damage = 10;
        public Trap(int id, string name, bool IsActive, int damage) : base(id, name, IsActive)
        {
        }

        public void ApplyDamage(int amount, Player player)
        {
            player.ApplyDamagePlayer(damage);
            if (amount > 0)
            {
                DisAble();
            }
            
        }
        public void ApplyDamage(int amount)
        {
        }

        public override string Info()
        {
            return "я ловушка." + ". Актиность: " + IsActive;
        }
        public string Interact(Player player)
        {
            ApplyDamage(damage, player);
            return $"Ваш герой попал в ловушку! Его здоровье теперь: {player.Hp}";
        }

    }
}
