﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Scene meow = new Scene();

            Player player = new Player(10, true, 100);

            Door door1 = new Door(1, "Секретная дверь", true);
            Door door2 = new Door(2, "Обычная дверь", false);

            Checkpoint checkpoint1 = new Checkpoint(10, "Начальная точка", true);
            Checkpoint checkpoint2 = new Checkpoint(20, "Средняя точка", true);

            Trap trap1 = new Trap(3, "Ловушка", true, 20);

            meow.AddObj(door1);
            meow.AddObj(door2);
            meow.AddObj(checkpoint1);
            meow.AddObj(checkpoint2);
            meow.AddObj(trap1);

            while (true)
            {
                Console.WriteLine("1.Показать все объекты");
                Console.WriteLine("2.Показать только интерактивные объекты");
                Console.WriteLine("3.Взаимодействовать с объектом по Id");
                Console.WriteLine("4.Отключить объект по Id");
                Console.WriteLine("5.Включить объект по Id");
                int pppp = IntInput(1, 5);
                if (pppp == 1)
                {
                    meow.PrintAll();
                }
                if (pppp == 2)
                {
                    meow.PrintOnlyInteractable();
                }
                if (pppp == 3)
                {

                }
            }
            
        }
        public static int IntInput(int min, int max)
        {
            int value;
            while (true)
            {
                Console.WriteLine($"Введите число от {min} до {max}!");
                if ( (int.TryParse(Console.ReadLine(), out value)) && value >= min && value <= max)
                {
                    return value;
                }
                else
                {
                    Console.WriteLine("Введен неверный формат!");
                }
            }
        }
    }
}
