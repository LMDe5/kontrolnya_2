﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal interface IDamageable
    {
        void ApplyDamage(int amount);
    }
}
