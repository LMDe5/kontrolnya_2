﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Light : GameObject, ITriggerable
    {
        private bool IsOn;

        public Light(int id, string name, bool isActive) : base(id, name, isActive)
        {
            IsOn = false;
        }

        public override string Info()
        {
            return $"Я свет." + "Актиность: " + IsActive;
        }

        public void Trigger()
        {
            IsOn = !IsOn;
            if (IsOn)
            {
                Console.WriteLine($"Свет переключен. Теперь он включен");
            }
            else
            {   
                Console.WriteLine($"Свет переключен. Теперь он выключен ");
            }
        }
    }
}
