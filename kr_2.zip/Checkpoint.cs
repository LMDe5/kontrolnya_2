﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Checkpoint : GameObject, IInteractable
    {
        public Checkpoint(int id, string name, bool IsActive) : base(id, name, IsActive)
        {
        }
        public override string Info()
        {
            return "я чекпоинт"+ ". Актиность: " + IsActive;
        }
        public string Interact(Player player)
        {
            player.LastCheckpointId = id;
            return "Чекпоинт был заменен!";
        }

    }
}
