﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Door : GameObject, IInteractable
    {
        public Door(int id, string name, bool isActive) : base(id, name, isActive)
        {

        }

        public string Interact(Player player)
        {
            if (requiredAccess == false)
            {
                return "Дверь открыта";
            }
            if (player.HasAccessCard == true)
            {
                return "Вы открыли дверб ключом!";
            }
            return "У вас нет ключа для открытия двери!";
        }
        private bool requiredAccess;
        public override string Info()
        {
            return "я дверь" + "Актиность: " + IsActive;
        }    
    }
}
