﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Button : GameObject, IInteractable
    {
        private ITriggerable target;
        public Button(int id, string name, bool IsActive, int oobject) : base(id, name, IsActive)
        {
        }

        public override string Info()
        {
            return "Я кнопка"+ ". Актиность: " + IsActive;
        }

        public Button(int id, string name, ITriggerable target, bool isActive = true)
            : base(id, name, isActive)
        {
            this.target = target;
        }
        public string Interact(Player player)
        {
            if (target != null)
            {
                target.Trigger();
                return "Кнопка нажата";
            }

            return "цель не установлена";
        }
    }
}