﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal class Scene
    {
        List<GameObject> Objects = new List<GameObject>();

        public Scene()
        {
        }
        public void AddObj(GameObject obj)
        {
            Objects.Add(obj);
        }
        public int GetListLenght()
        {
            return Objects.Count;
        }
        public void PrintAll()
        {
            foreach (var obj in Objects)
            {
                Console.WriteLine(obj.Info());
            }
        }
        public void PrintOnlyInteractable()
        {
            for (int i = 0;  i < Objects.Count; i++)
            {
                if (Objects[i] is IInteractable)
                {
                    Console.WriteLine(Objects[i].Info());
                }
            }
        }
    }
}
