﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThE_GrEaTeSt_CoNtRoShA_2
{
    internal abstract class GameObject
    {
        protected int id;
        protected string name;
        public bool IsActive { get; protected set; }

        public GameObject(int id, string name, bool IsActive)
        {
            this.id = id;
            this.name = name;
            this.IsActive = IsActive;
        }

        protected void EnAble()
        {
            IsActive = true;
        }

        protected void DisAble()
        {
            IsActive = false;
        }
        public int GetId()
        {
            return id;
        }
        public abstract string Info();
    }
}
